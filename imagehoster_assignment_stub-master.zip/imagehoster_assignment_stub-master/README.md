# imagehoster_assignment_stub
ImageHoster Assignment code
